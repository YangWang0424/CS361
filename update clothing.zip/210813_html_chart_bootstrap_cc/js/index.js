// 0. 如果使用模块化机制编程，导入Vue和VueRouter，要调用 Vue.use(VueRouter)

// define component content
const homeContent = $("#home_content").html();
const Home = { template: homeContent }


function setErrorMessage(message){
  $("#errorData").html(message);
}

function getErrorMessage(){
  return globalErrorMessage;
}

function showPie(dom, title, data){
  let options = {
    
    title: {
        text: title,
        left: 'center'
    },
    series: [
        {
            name: title,
            type: 'pie',
            radius: '50%',
            data: data
        }
    ]
  }
  let myChart = echarts.init(dom);
  myChart.setOption(options);
}

function showBar(dom, xtitle, ytitle, xdata, ydata){
  
  var myChart = echarts.init(dom);
  var option = {
      calculable: true,
      xAxis: {
          type: 'category',
          name: xtitle,
          data: xdata
      },
      yAxis: {
          type: 'value',
          name: ytitle,
          axisLine: {
              show: true
          }
      },
      series: [{
          label: {
              show: true,
              position: 'top'
          },
          data: ydata,
          type: 'bar'
      }]
  };

  myChart.setOption(option);
}
const Online = { template: $("#online_content").html(),
  data:()=>{
    return {
      pieYear:"", 
      years:["2015", "2016", "2017"] // the years have data
    }
  },
  methods:{
    showPie:showPie,
    showPieByYear:function(){
      if(this.years.indexOf(this.pieYear) < 0){

        console.log("show year bad", this.pieYear);
        if(this.pieYear == ""){
          setErrorMessage("Please input a year.");
        }else{
          setErrorMessage("There is no data of year " + this.pieYear + ".");
        }
        var myModal = new bootstrap.Modal(document.getElementById('errorMessage'));
        myModal.show();

      }else{
        
        if(this.pieYear == "2015"){
          this.showPie(this.$refs.salesPie, "2015", [
            {value: 0.35, name: 'Polyester'},
            {value: 0.25, name: 'Other'},
            {value: 0.2, name: 'Cotton'},
            {value: 0.12, name: 'Cellulosies'},
            {value: 0.08, name: 'wool'}
          ]);
        }
        
        if(this.pieYear == "2016"){
          this.showPie(this.$refs.salesPie, "2016", [
            {value: 0.25, name: 'Polyester'},
            {value: 0.2, name: 'Other'},
            {value: 0.45, name: 'Cotton'},
            {value: 0.1, name: 'wool'}
          ]);
        }
        if(this.pieYear == "2017"){
          this.showPie(this.$refs.salesPie, "2017", [
              {value: 0.3, name: 'Polyester'},
              {value: 0.25, name: 'Cotton'},
              {value: 0.25, name: 'wool'},
              {value: 0.2, name: 'Other'}
          ]);
        }


      }
    }
  } , mounted:function(){
    showBar(this.$refs.online_sales, "year", "online sales", 
    ['2008', '2009', '2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017'],
    [120, 200, 1500, 800, 700, 1100, 1300, 1250, 2640, 3000]
    );


  }
};

const Offline = { template: $("#offline_content").html() ,
data:()=>{
  return {
    pieYear:"",
    years:["2015", "2016", "2017"]
  }
},
methods:{
  showPie:showPie,
  showPieByYear:function(){
    if(this.years.indexOf(this.pieYear) < 0){

      console.log("show year bad", this.pieYear);
      if(this.pieYear == ""){
        setErrorMessage("Please input a year.");
      }else{
        setErrorMessage("There is no data of year " + this.pieYear + ".");
      }
      var myModal = new bootstrap.Modal(document.getElementById('errorMessage'));
      myModal.show();

    }else{
      
      if(this.pieYear == "2015"){
        this.showPie(this.$refs.salesPie, "2015", [
          {value: 0.35, name: 'Polyester'},
          {value: 0.25, name: 'Other'},
          {value: 0.2, name: 'Cotton'},
          {value: 0.12, name: 'Cellulosies'},
          {value: 0.08, name: 'wool'}
        ]);
      }
      
      if(this.pieYear == "2016"){
        this.showPie(this.$refs.salesPie, "2016", [
          {value: 0.25, name: 'Polyester'},
          {value: 0.2, name: 'Other'},
          {value: 0.45, name: 'Cotton'},
          {value: 0.1, name: 'wool'}
        ]);
      }
      if(this.pieYear == "2017"){
        this.showPie(this.$refs.salesPie, "2017", [
            {value: 0.3, name: 'Polyester'},
            {value: 0.25, name: 'Cotton'},
            {value: 0.25, name: 'wool'},
            {value: 0.2, name: 'Other'}
        ]);
      }


    }
  }
} , mounted:function(){
  showBar(this.$refs.online_sales, "year", "offline sales", 
  ['2008', '2009', '2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017'],
  [120, 200, 1000, 1800, 700, 2100, 1300, 1250, 640, 300]
  );


  
}};
const Analyze = { template: $("#analyze_content").html(),
  data:()=>{return {
    process:0
  }},
  methods:{
    showChart:function(){

      var dom = this.$refs.analyze;
      if(dom == null){
        console.log("no analyze dom");
        return;
      }
      var myChart = echarts.init(dom);
  
      var option;
  
      option = {
          tooltip: {
              trigger: 'axis',
              axisPointer: {
                  type: 'shadow'
              }
          },
          legend: {
              data: ['Inventory', 'Need to purchase']
          },
          grid: {
              left: '3%',
              right: '4%',
              bottom: '3%',
              containLabel: true
          },
          xAxis: {
              type: 'value'
          },
          yAxis: {
              type: 'category',
              data: ['Wool', 'Polyester', 'Linen', 'Cotton']
          },
          series: [
              {
                  name: 'Inventory',
                  type: 'bar',
                  stack: 'total',
                  label: {
                      show: true
                  },
                  emphasis: {
                      focus: 'series'
                  },
                  data: [3200000, 3020000, 3010000, 3340000]
              },
              {
                  name: 'Need to purchase',
                  type: 'bar',
                  stack: 'total',
                  label: {
                      show: true
                  },
                  emphasis: {
                      focus: 'series'
                  },
                  data: [1200000, 1320000, 1010000, 1340000]
              }
          ]
      };
  
      if (option && typeof option === 'object') {
          myChart.setOption(option);
      }
    },
    loadProcess:function(){
      let self = this;
      setTimeout(() => {
        self.setProcess();
      }, 80);
    },
    setProcess:function(){
      this.process += 1;
      if(this.process < 100){
        this.loadProcess();
      }else{
        this.showChart();
      }
    }
  }, 
  mounted:function(){
    this.loadProcess();
    // this.showChart();
  }
};

const routes = [
  { path: '/Home', component: Home },
  { path: '/online', component: Online },
  { path: '/offline', component: Offline },
  { path: '/analyze', component: Analyze }
]

// create router instance
const router = new VueRouter({
  routes:routes
});

// create and mount root instance
const app = new Vue({
  router,
  mounted(){
  },
  methods:{
    changePage:function(){
      console.log("change page");
    }
  },
}).$mount('#app');

