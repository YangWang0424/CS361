
    var dom = document.getElementById("online_sales");
    var myChart = echarts.init(dom);
    var option;

    option = {
        calculable: true,
        xAxis: {
            type: 'category',
            name:'year',
            data: ['2008', '2009', '2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017']
        },
        yAxis: {
            type: 'value',
            name:'sales',
            axisLine: {
                show: true
            }
        },
        series: [{
            label: {
                show: true,
                position: 'top'
            },
            data: [1200000000, 200000000, 1500000000, 800000000, 700000000, 1100000000, 1300000000, 1250000000, 2640000000, 3000000000],
            type: 'bar'
        }]
    };

    if (option && typeof option === 'object') {
        myChart.setOption(option);
    }


    var dom1 = document.getElementById("salesPip1");
    var myChart1 = echarts.init(dom1);

    var option1;



    option1 = {
        title: {
            text: '2015',
            left: 'center'
        },
        series: [
            {
                name: '2015',
                type: 'pie',
                radius: '50%',
                data: [
                    {value: 0.35, name: 'Polyester'},
                    {value: 0.25, name: 'Other'},
                    {value: 0.2, name: 'Cotton'},
                    {value: 0.12, name: 'Cellulosies'},
                    {value: 0.08, name: 'wool'}
                ]
            }
        ]
    };

    if (option1 && typeof option1 === 'object') {
        myChart1.setOption(option1);
    }

    var dom2 = document.getElementById("salesPip2");
    var myChart2 = echarts.init(dom2);

    var option2;



    option2 = {
        title: {
            text: '2016',
            left: 'center'
        },
        series: [
            {
                name: '2016',
                type: 'pie',
                radius: '50%',
                data: [
                    {value: 0.25, name: 'Polyester'},
                    {value: 0.2, name: 'Other'},
                    {value: 0.45, name: 'Cotton'},
                    {value: 0.1, name: 'wool'}
                ]
            }
        ]
    };

    if (option2 && typeof option2 === 'object') {
        myChart2.setOption(option2);
    }


    var dom3 = document.getElementById("salesPip3");
    var myChart3 = echarts.init(dom3);

    var option3;



    option3 = {
        title: {
            text: '2017',
            left: 'center'
        },
        series: [
            {
                name: '2017',
                type: 'pie',
                radius: '50%',
                data: [
                    {value: 0.3, name: 'Polyester'},
                    {value: 0.25, name: 'Cotton'},
                    {value: 0.25, name: 'wool'},
                    {value: 0.2, name: 'Other'}
                ]
            }
        ]
    };

    if (option3 && typeof option3 === 'object') {
        myChart3.setOption(option3);
    }